data = [28, 20, 15, 12, 10, 8, 7]; % Corresponding percentages
names = {'Mobiltech', 'Meditech', 'Buildtech', 'Hometech', 'Agrotech', 'Clothtech', 'Packtech'}; % Labels for each category
d = donutchart(data,names);

% Data for the pie chart
labels = {'Mobiltech', 'Meditech', 'Buildtech', 'Hometech', 'Agrotech', 'Clothtech', 'Packtech'}; % Labels for each category
percentages = [28, 20, 15, 12, 10, 8, 7]; % Corresponding percentages