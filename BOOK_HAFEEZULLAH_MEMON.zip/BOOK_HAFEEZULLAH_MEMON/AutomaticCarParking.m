% Automatic Car Parking System with UI

function AutomaticCarParking()
    createUI();
end

function nextPose = vehicleDynamics(currentPose, speed, steeringAngle)
    % Update vehicle pose based on speed and steering angle
    wheelbase = 2.5; % Example wheelbase length
    nextPose(1) = currentPose(1) + speed * cos(currentPose(3));
    nextPose(2) = currentPose(2) + speed * sin(currentPose(3));
    nextPose(3) = currentPose(3) + (speed / wheelbase) * tan(steeringAngle);
end

function createUI()
    f = figure('Position', [100 100 600 400]);
    
    uicontrol('Style', 'pushbutton', 'String', 'Start Parking', ...
              'Position', [20 350 100 30], ...
              'Callback', @startParking);
    
    axes('Position', [0.3 0.1 0.6 0.8]); % Area for visualization
    
    % Initialize parking lot and display it
    freeSpots = [2, 2; 4, 4; 6, 6];
    obstacles = [3, 3; 5, 5];
    parkingLot = ParkingLot(freeSpots, obstacles);
    
    % Display the parking lot
    parkingLot.display();
    
    % Store the parking lot in the figure's UserData for access in callback
    set(f, 'UserData', parkingLot);
end

function startParking(~, ~)
    f = gcf;
    parkingLot = get(f, 'UserData');
    
    % Initial vehicle pose: [x, y, theta]
    vehiclePose = [0, 0, pi/4]; % Starting position and orientation
    speed = 0.1; % Speed of the vehicle
    
    % Simulate the parking process
    for i = 1:100
        steeringAngle = -pi/18; % Example steering angle to turn left
        
        % Update vehicle dynamics
        vehiclePose = vehicleDynamics(vehiclePose, speed, steeringAngle);
        
        % Update visualization
        updateVisualization(vehiclePose);
        
        pause(0.1); % Pause for visualization effect
        
        if norm(vehiclePose(1:2) - parkingLot.FreeSpots(1,:)) < 0.5
            disp('Vehicle parked successfully!');
            break;
        end
    end
end

function updateVisualization(vehiclePose)
    axesHandle = gca;
    
    % Clear previous vehicle position
    cla(axesHandle);
    
    % Redraw the parking lot and vehicle position
    parkingLot = get(gcf, 'UserData');
    parkingLot.display();
    
    % Draw the vehicle as a blue triangle (simple representation)
    fill(vehiclePose(1) + [-0.2, 0.2, -0.2]*cos(vehiclePose(3)), ...
         vehiclePose(2) + [-0.2, -0.2, 0.2]*sin(vehiclePose(3), ...
         'b');
end

% Run the main function to start the application.
AutomaticCarParking();