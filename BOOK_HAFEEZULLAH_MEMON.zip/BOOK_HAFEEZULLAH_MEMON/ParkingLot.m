classdef ParkingLot
    properties
        FreeSpots
        Obstacles
    end
    
    methods
        function obj = ParkingLot(freeSpots, obstacles)
            obj.FreeSpots = freeSpots;
            obj.Obstacles = obstacles;
        end
        
        function display(obj)
            % Visualize parking lot
            hold on;
            plot(obj.FreeSpots(:,1), obj.FreeSpots(:,2), 'go', 'MarkerSize', 10); % Free spots
            plot(obj.Obstacles(:,1), obj.Obstacles(:,2), 'ro', 'MarkerSize', 10); % Obstacles
            hold off;
            axis([0 10 0 10]);
            grid on;
            title('Parking Lot');
        end
    end
end